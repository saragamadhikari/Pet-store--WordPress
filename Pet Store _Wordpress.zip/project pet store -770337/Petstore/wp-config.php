<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'petstore1' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'G<F{5 Yob|?^e&xVW#Q-S7lA7#][qD?iRPk=Fca~N*4@PruVNg?u{etoAxuY#$F!' );
define( 'SECURE_AUTH_KEY',  'Nu*`ut?D=o9ra(_yHz1Tc[G;K%KYQY/}EY;u17Icg0$|O]H m10J8OZSUoWg*5~K' );
define( 'LOGGED_IN_KEY',    ')/Tu=HhSnt ela,bQZ^SP8Q!6G<+/YTq}i+r;8<)(SOB-ji{cDfg-+sdt[70K0cN' );
define( 'NONCE_KEY',        'nM]%q-6Afj(EDWs6lNc2&|DI?Jfy;V4>u.!,*~R)r2_Zo(#>`a1zsc@4C?34N6yX' );
define( 'AUTH_SALT',        '?B3OFF,5ATze:x[j=6 bfFx|<)dbj(w?]u89YeflP<%k+^{Lj6}(!?~AwP*}QIN(' );
define( 'SECURE_AUTH_SALT', '&*j~9Jf4)$o=cA_w1EO2T0Mao-CwIDzWkA1Pz)EAIU38fbbh7Sf{|_bdLF;aC DA' );
define( 'LOGGED_IN_SALT',   'O3_^.h5=#r^?e(I7LQN{p7_*)0pd7-@E5p??05DGDA2= Q(}o=1mi(r(*^qW~HO(' );
define( 'NONCE_SALT',       '<qs^RSV)q>F9)/Ni -IVh4O#J!&cGP:y!7Q8IIxI)b0G.0|hKO{@kg[B._aL?v! ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
